
import mongoose from 'mongoose';

const CommandLogSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  command: String,
  arguments: [String],
  timestamp: { type: Date, default: Date.now },
  target: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  room: { type: String, default: null },
  status: { type: String, enum: ['success', 'fail'], default: 'success' },
  role: { type: String },
  details: Object,
});

export default mongoose.models.CommandLog || mongoose.model('CommandLog', CommandLogSchema);
